#!/usr/bin/env bash
# Integrated launcher.  ./run.sh [menu|demo|test|all]
set -eu
cd "$(dirname "$0")"
mkdir -p logs outputs
command -v python3 >/dev/null || { echo "python3 required"; exit 1; }
python3 -c "import matplotlib" 2>/dev/null || { echo "Install matplotlib: pip install matplotlib"; exit 1; }
case "${1:-menu}" in
  menu) python3 main.py ;;
  demo) python3 main.py --demo | tee outputs/demo_trace.txt ;;
  test) python3 -m unittest discover -s tests -v 2>&1 | tee outputs/test_results.txt ;;
  all)  "$0" demo; "$0" test; bash bash/archive_logs.sh ;;
  *)    echo "usage: $0 [menu|demo|test|all]"; exit 2 ;;
esac
