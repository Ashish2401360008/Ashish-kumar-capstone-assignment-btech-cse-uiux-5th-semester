"""CPU scheduling: FCFS, SJF, SRTF, Priority, Round Robin."""
from .errors import ValidationError

def _merge(g):
    out = []
    for pid, s, e in g:
        if out and out[-1][0] == pid and out[-1][2] == s:
            out[-1] = (pid, out[-1][1], e)
        else:
            out.append((pid, s, e))
    return out

def _finish(procs, gantt, completion, first_run):
    rows = []
    for p in procs:
        ct = completion[p["pid"]]
        tat = ct - p["arrival"]
        rows.append({"pid": p["pid"], "arrival": p["arrival"], "burst": p["burst"],
                     "completion": ct, "turnaround": tat, "waiting": tat - p["burst"],
                     "response": first_run[p["pid"]] - p["arrival"]})
    n = len(rows)
    span = max(r["completion"] for r in rows) - min(p["arrival"] for p in procs)
    busy = sum(p["burst"] for p in procs)
    return {"rows": rows, "gantt": _merge(gantt),
            "avg_waiting": sum(r["waiting"] for r in rows) / n,
            "avg_turnaround": sum(r["turnaround"] for r in rows) / n,
            "avg_response": sum(r["response"] for r in rows) / n,
            "cpu_util": 100.0 * busy / span if span else 100.0,
            "throughput": n / span if span else float(n)}

def _check(procs):
    if not procs:
        raise ValidationError("No processes supplied")

def _nonpreemptive(procs, key):
    _check(procs)
    pending, t, gantt, comp, first = sorted(procs, key=lambda p: p["arrival"]), 0, [], {}, {}
    while pending:
        ready = [p for p in pending if p["arrival"] <= t]
        if not ready:
            t = pending[0]["arrival"]; continue
        p = min(ready, key=lambda x: (key(x), x["arrival"]))
        pending.remove(p)
        first[p["pid"]] = t
        gantt.append((p["pid"], t, t + p["burst"]))
        t += p["burst"]; comp[p["pid"]] = t
    return _finish(procs, gantt, comp, first)

def fcfs(procs):      return _nonpreemptive(procs, lambda p: p["arrival"])
def sjf(procs):       return _nonpreemptive(procs, lambda p: p["burst"])
def priority(procs):  return _nonpreemptive(procs, lambda p: p["priority"])

def srtf(procs):
    _check(procs)
    rem = {p["pid"]: p["burst"] for p in procs}
    t, gantt, comp, first = 0, [], {}, {}
    while rem:
        ready = [p for p in procs if p["pid"] in rem and p["arrival"] <= t]
        if not ready:
            t = min(p["arrival"] for p in procs if p["pid"] in rem); continue
        p = min(ready, key=lambda x: (rem[x["pid"]], x["arrival"]))
        first.setdefault(p["pid"], t)
        gantt.append((p["pid"], t, t + 1)); t += 1; rem[p["pid"]] -= 1
        if rem[p["pid"]] == 0:
            del rem[p["pid"]]; comp[p["pid"]] = t
    return _finish(procs, gantt, comp, first)

def round_robin(procs, quantum=4):
    _check(procs)
    if not isinstance(quantum, int) or quantum < 1:
        raise ValidationError(f"Quantum must be a positive integer, got {quantum!r}")
    order = sorted(procs, key=lambda p: p["arrival"])
    rem = {p["pid"]: p["burst"] for p in procs}
    queue, t, i, gantt, comp, first = [], 0, 0, [], {}, {}
    while i < len(order) or queue:
        if not queue:
            t = max(t, order[i]["arrival"])
        while i < len(order) and order[i]["arrival"] <= t:
            queue.append(order[i]); i += 1
        p = queue.pop(0); pid = p["pid"]
        first.setdefault(pid, t)
        run = min(quantum, rem[pid])
        gantt.append((pid, t, t + run)); t += run; rem[pid] -= run
        while i < len(order) and order[i]["arrival"] <= t:
            queue.append(order[i]); i += 1
        if rem[pid]:
            queue.append(p)
        else:
            comp[pid] = t
    return _finish(procs, gantt, comp, first)

ALGORITHMS = {"FCFS": fcfs, "SJF": sjf, "SRTF": srtf, "Priority": priority,
              "RR(q=4)": lambda p: round_robin(p, 4)}

def compare(procs):
    return {name: fn(procs) for name, fn in ALGORITHMS.items()}
