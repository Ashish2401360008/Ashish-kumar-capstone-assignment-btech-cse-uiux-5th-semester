"""Deadlock handling: Banker's algorithm (avoidance) + wait-for-graph detection."""
from .errors import ValidationError

def validate_state(alloc, maxm, avail):
    n = len(alloc)
    if n == 0 or len(maxm) != n:
        raise ValidationError("allocation and max matrices must be non-empty and equal height")
    m = len(avail)
    for name, mat in (("allocation", alloc), ("max", maxm)):
        for row in mat:
            if len(row) != m:
                raise ValidationError(f"{name} row width {len(row)} != {m} resource types")
            if any((not isinstance(x, int)) or x < 0 for x in row):
                raise ValidationError(f"{name} contains negative/non-integer value")
    if any(x < 0 for x in avail):
        raise ValidationError("available contains negative value")
    for i in range(n):
        if any(alloc[i][j] > maxm[i][j] for j in range(m)):
            raise ValidationError(f"P{i}: allocation exceeds declared max")

def safety(alloc, maxm, avail):
    validate_state(alloc, maxm, avail)
    n, m = len(alloc), len(avail)
    need = [[maxm[i][j] - alloc[i][j] for j in range(m)] for i in range(n)]
    work, done, seq, steps = list(avail), [False] * n, [], []
    progress = True
    while progress:
        progress = False
        for i in range(n):
            if not done[i] and all(need[i][j] <= work[j] for j in range(m)):
                steps.append((f"P{i}", list(work)))
                work = [work[j] + alloc[i][j] for j in range(m)]
                done[i] = True; seq.append(f"P{i}"); progress = True
    return {"safe": all(done), "sequence": seq, "need": need,
            "stuck": [f"P{i}" for i in range(n) if not done[i]], "steps": steps}

def request(alloc, maxm, avail, pid, req):
    validate_state(alloc, maxm, avail)
    if not (0 <= pid < len(alloc)):
        raise ValidationError(f"Unknown process P{pid}")
    if len(req) != len(avail) or any(x < 0 for x in req):
        raise ValidationError("Invalid request vector")
    need = [maxm[pid][j] - alloc[pid][j] for j in range(len(avail))]
    if any(req[j] > need[j] for j in range(len(avail))):
        return {"granted": False, "reason": "request exceeds declared maximum claim"}
    if any(req[j] > avail[j] for j in range(len(avail))):
        return {"granted": False, "reason": "resources not available; process must wait"}
    a2 = [list(r) for r in alloc]; av2 = list(avail)
    for j in range(len(avail)):
        a2[pid][j] += req[j]; av2[j] -= req[j]
    s = safety(a2, maxm, av2)
    return {"granted": s["safe"],
            "reason": "safe state preserved" if s["safe"] else "would lead to UNSAFE state",
            "sequence": s["sequence"]}

def detect_cycle(wait_for):
    """wait_for: {'P1': ['P2'], ...}. Returns a cycle (list) or None."""
    state, stack = {}, []
    def dfs(u):
        state[u] = 1; stack.append(u)
        for v in wait_for.get(u, []):
            if state.get(v) == 1:
                return stack[stack.index(v):] + [v]
            if state.get(v) is None:
                c = dfs(v)
                if c: return c
        state[u] = 2; stack.pop()
        return None
    for node in list(wait_for):
        if state.get(node) is None:
            c = dfs(node)
            if c: return c
    return None
