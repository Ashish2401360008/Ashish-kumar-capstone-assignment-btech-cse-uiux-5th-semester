"""Reusable input validation (valid / invalid / boundary handling)."""
import csv
from .errors import ValidationError

def positive_int(value, name, minimum=1, maximum=10**6):
    try:
        v = int(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{name} must be an integer, got {value!r}")
    if not (minimum <= v <= maximum):
        raise ValidationError(f"{name} must be in [{minimum}, {maximum}], got {v}")
    return v

def int_list(text, name, minimum=0, maximum=10**6):
    if isinstance(text, str):
        text = text.replace(",", " ").split()
    if not text:
        raise ValidationError(f"{name} must not be empty")
    return [positive_int(t, name, minimum, maximum) for t in text]

def load_processes(path):
    """CSV columns: pid,arrival,burst,priority"""
    try:
        f = open(path, newline="")
    except OSError as e:
        raise ValidationError(f"Cannot open {path}: {e.strerror}")
    procs, seen = [], set()
    with f:
        for n, row in enumerate(csv.DictReader(f), start=2):
            try:
                pid = row["pid"].strip()
                p = {"pid": pid,
                     "arrival": positive_int(row["arrival"], "arrival", 0, 10**5),
                     "burst": positive_int(row["burst"], "burst", 1, 10**5),
                     "priority": positive_int(row.get("priority") or 1, "priority", 1, 100)}
            except (KeyError, AttributeError):
                raise ValidationError(f"{path} line {n}: missing column (need pid,arrival,burst,priority)")
            except ValidationError as e:
                raise ValidationError(f"{path} line {n}: {e}")
            if not pid or pid in seen:
                raise ValidationError(f"{path} line {n}: empty or duplicate pid {pid!r}")
            seen.add(pid)
            procs.append(p)
    if not procs:
        raise ValidationError(f"{path} contains no processes")
    return procs
