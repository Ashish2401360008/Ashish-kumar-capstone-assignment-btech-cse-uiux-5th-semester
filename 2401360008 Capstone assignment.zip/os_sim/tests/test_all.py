import os, sys, tempfile, unittest, shutil
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from osim import scheduler, memory, deadlock, storage, bash_bridge
from osim.errors import ValidationError
from osim.validators import load_processes, int_list, positive_int

P = [{"pid": "A", "arrival": 0, "burst": 5, "priority": 2},
     {"pid": "B", "arrival": 1, "burst": 3, "priority": 1},
     {"pid": "C", "arrival": 2, "burst": 1, "priority": 3}]

class TestScheduler(unittest.TestCase):
    def test_fcfs_known_values(self):
        r = scheduler.fcfs(P)
        self.assertAlmostEqual(r["avg_waiting"], (0 + 4 + 6) / 3)
    def test_sjf_beats_fcfs_waiting(self):
        self.assertLessEqual(scheduler.sjf(P)["avg_waiting"], scheduler.fcfs(P)["avg_waiting"])
    def test_srtf_optimal_waiting(self):
        res = scheduler.compare(P)
        self.assertEqual(min(res, key=lambda n: res[n]["avg_waiting"]), "SRTF")
    def test_conservation(self):  # waiting = turnaround - burst for every algorithm
        for r in scheduler.compare(P).values():
            for row in r["rows"]:
                self.assertEqual(row["waiting"], row["turnaround"] - row["burst"])
    def test_idle_gap(self):
        r = scheduler.fcfs([{"pid": "X", "arrival": 5, "burst": 2, "priority": 1}])
        self.assertEqual(r["gantt"], [("X", 5, 7)]); self.assertEqual(r["cpu_util"], 100.0)
    def test_single_process_boundary(self):
        self.assertEqual(scheduler.round_robin(P[:1], 100)["avg_waiting"], 0)
    def test_invalid_quantum(self):
        for q in (0, -1, "x"):
            with self.assertRaises(ValidationError): scheduler.round_robin(P, q)
    def test_empty(self):
        with self.assertRaises(ValidationError): scheduler.fcfs([])

class TestMemory(unittest.TestCase):
    R = [7,0,1,2,0,3,0,4,2,3,0,3,2,1,2,0,1,7,0,1]
    def test_textbook_values(self):
        self.assertEqual(memory.fifo(self.R, 3)["faults"], 15)
        self.assertEqual(memory.lru(self.R, 3)["faults"], 12)
        self.assertEqual(memory.optimal(self.R, 3)["faults"], 9)
    def test_belady_anomaly(self):
        b = [1,2,3,4,1,2,5,1,2,3,4,5]
        self.assertEqual((memory.fifo(b, 3)["faults"], memory.fifo(b, 4)["faults"]), (9, 10))
    def test_optimal_is_lower_bound(self):
        for f in range(1, 6):
            self.assertLessEqual(memory.optimal(self.R, f)["faults"], memory.lru(self.R, f)["faults"])
    def test_boundary_one_frame(self):
        self.assertEqual(memory.lru([1, 1, 1], 1)["faults"], 1)
    def test_invalid(self):
        with self.assertRaises(ValidationError): memory.fifo([], 3)
        with self.assertRaises(ValidationError): memory.fifo([1], 0)
    def test_allocation(self):
        a = memory.allocate([100, 500, 200, 300, 600], [212, 417, 112, 426], "best")
        self.assertEqual(a["unplaced"], [])
        with self.assertRaises(ValidationError): memory.allocate([10], [5], "random")

class TestDeadlock(unittest.TestCase):
    A = [[0,1,0],[2,0,0],[3,0,2],[2,1,1],[0,0,2]]
    M = [[7,5,3],[3,2,2],[9,0,2],[2,2,2],[4,3,3]]
    V = [3,3,2]
    def test_safe(self):
        s = deadlock.safety(self.A, self.M, self.V)
        self.assertTrue(s["safe"]); self.assertEqual(s["sequence"], ["P1","P3","P4","P0","P2"])
    def test_unsafe(self):
        s = deadlock.safety([[1,0],[0,1]], [[1,1],[1,1]], [0,0])
        self.assertFalse(s["safe"]); self.assertEqual(s["stuck"], ["P0", "P1"])
    def test_request_granted_and_denied(self):
        self.assertTrue(deadlock.request(self.A, self.M, self.V, 1, [1,0,2])["granted"])
        self.assertFalse(deadlock.request(self.A, self.M, self.V, 4, [3,3,0])["granted"])
        self.assertFalse(deadlock.request(self.A, self.M, self.V, 0, [8,0,0])["granted"])
    def test_invalid_state(self):
        with self.assertRaises(ValidationError): deadlock.safety([[5]], [[1]], [0])
        with self.assertRaises(ValidationError): deadlock.safety([[1, 1]], [[2]], [0])
        with self.assertRaises(ValidationError): deadlock.request(self.A, self.M, self.V, 9, [0,0,0])
    def test_cycle_detection(self):
        self.assertEqual(deadlock.detect_cycle({"A": ["B"], "B": ["A"]}), ["A", "B", "A"])
        self.assertIsNone(deadlock.detect_cycle({"A": ["B"], "B": []}))

class TestStorage(unittest.TestCase):
    R = [98,183,37,122,14,124,65,67]
    def test_textbook(self):
        self.assertEqual(storage.fcfs(self.R, 53)["total_movement"], 640)
        self.assertEqual(storage.sstf(self.R, 53)["total_movement"], 236)
    def test_look_not_worse_than_scan(self):
        self.assertLessEqual(storage.look(self.R, 53)["total_movement"], storage.scan(self.R, 53)["total_movement"])
    def test_boundaries(self):
        self.assertEqual(storage.fcfs([0], 0)["total_movement"], 0)
        self.assertEqual(storage.fcfs([199], 0)["total_movement"], 199)
    def test_invalid(self):
        with self.assertRaises(ValidationError): storage.fcfs([200], 0)
        with self.assertRaises(ValidationError): storage.sstf([], 5)
        with self.assertRaises(ValidationError): storage.scan([5], -1)

class TestValidatorsAndBash(unittest.TestCase):
    def _csv(self, text):
        f = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False); f.write(text); f.close()
        self.addCleanup(os.remove, f.name); return f.name
    def test_valid_csv(self):
        self.assertEqual(len(load_processes(self._csv("pid,arrival,burst,priority\nA,0,3,1\n"))), 1)
    def test_bad_rows(self):
        for body in ("pid,arrival,burst,priority\nA,0,0,1\n",      # zero burst
                     "pid,arrival,burst,priority\nA,-1,3,1\n",     # negative arrival
                     "pid,arrival,burst,priority\nA,x,3,1\n",      # non-numeric
                     "pid,arrival,burst,priority\nA,0,3,1\nA,1,1,1\n",  # duplicate
                     "pid,arrival,burst,priority\n",               # empty
                     "name,t\nA,1\n"):                             # wrong header
            with self.assertRaises(ValidationError): load_processes(self._csv(body))
    def test_missing_file(self):
        with self.assertRaises(ValidationError): load_processes("/no/such/file.csv")
    def test_int_helpers(self):
        self.assertEqual(int_list("1, 2 3", "x"), [1, 2, 3])
        with self.assertRaises(ValidationError): int_list("1 a", "x")
        with self.assertRaises(ValidationError): positive_int(10**7, "x")
    @unittest.skipUnless(shutil.which('bash'), 'Bash is not installed; install Git for Windows to test Bash integration')
    def test_bash_integration(self):
        self.assertIn("Memory:", bash_bridge.sysinfo())
        with self.assertRaises(ValidationError): bash_bridge.run_script("collect_procs.sh", "abc")
        with self.assertRaises(ValidationError): bash_bridge.run_script("nope.sh")

if __name__ == "__main__":
    unittest.main(verbosity=2)
