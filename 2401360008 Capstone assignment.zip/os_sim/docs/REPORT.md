# Capstone Report – OS Resource-Management Simulator

## Phase 1 – System design and planning
**Problem.** Operating systems arbitrate scarce resources (CPU, memory, devices, disk). This project simulates those
decisions in one integrated tool so alternative policies can be compared on identical data.

**Architecture.** `main.py` (menu/CLI) → independent modules (`scheduler`, `memory`, `deadlock`, `storage`) → shared
services (`validators`, `logger`, `report`, `bash_bridge`). Modules are pure functions that take validated data and
return dictionaries; only `main.py` does I/O, so everything is unit-testable.

**Workflow.** file/keyboard input → validation → simulation → metrics → table + chart + log entry.

**Data design.** Process = dict(pid, arrival, burst, priority). Schedule result = Gantt list of (pid, start, end) +
per-process rows + averages. Page trace = list of (page, frames, HIT/FAULT). Banker's state = three integer matrices.
Disk result = service order + total movement.

**Implementation plan.** (1) validators/logger → (2) scheduler → (3) memory → (4) deadlock → (5) storage →
(6) Bash helpers → (7) reporting/charts → (8) menu → (9) tests → (10) documentation.

## Phase 2 – Core modules (5 implemented, 3 required)
Scheduling, memory, deadlock, storage and reporting; Bash is integrated in the reporting module (host snapshot,
live-process dataset) and in log archiving.

## Phase 3 – Analysis and comparison (sample data in `data/`)
**CPU scheduling** (6 processes): 

| Algorithm | Avg WT | Avg TAT | Avg RT |
|---|---|---|---|
| FCFS | 12.50 | 18.17 | 12.50 |
| SJF | 9.33 | 15.00 | 9.33 |
| SRTF | **8.00** | **13.67** | **4.83** |
| Priority | 12.00 | 17.67 | 12.00 |
| RR (q=4) | 15.67 | 21.33 | 7.67 |

*Observations.* SRTF minimises waiting/turnaround (it is provably optimal for average waiting time) but needs burst
estimates and risks starving long jobs (P3 finishes last). FCFS suffers the convoy effect behind P1/P3. RR gives the
second-best response time and is fair, but its many context switches inflate waiting time for short-job mixes.

**Page replacement** (20-reference string, 3 frames): FIFO 15 faults, LRU 12, Optimal 9 (the theoretical lower bound).
All three converge at 6 faults once frames ≥ 6 (distinct pages = 6). Belady's anomaly for FIFO is verified in
`test_belady_anomaly` (string 1 2 3 4 1 2 5 1 2 3 4 5: 9 faults with 3 frames, 10 with 4).
**Allocation:** best-fit placed all four requests (68.6 % utilisation); first- and worst-fit could not place 426.

**Disk scheduling** (head 53): FCFS 640, SSTF 236, LOOK 299, SCAN 331, C-SCAN 382 cylinders. SSTF is lowest but can
starve distant requests; LOOK/SCAN family bound waiting time and are preferred under heavy load.

**Deadlock:** the sample state is safe (sequence P1→P3→P4→P0→P2); a request P1[1,0,2] is granted; P0[0,4,0] is denied
(unavailable). The wait-for graph P1→P2→P3→P1 is detected as a deadlock cycle.

Charts: `gantt_comparison.png`, `scheduler_metrics.png`, `page_faults.png`, `disk_scheduling.png`.

## Phase 4 – Testing and reliability
28 automated tests (`tests/test_all.py`, all pass – see `outputs/test_results.txt`).

| Category | Examples |
|---|---|
| Valid | textbook results (FIFO 15/LRU 12/OPT 9; FCFS 640/SSTF 236 disk; Banker safe sequence) |
| Boundary | 1 frame; single process; head at cylinder 0 / 199; idle CPU gap before first arrival; max-range ints |
| Invalid | quantum ≤ 0 or non-numeric; empty queues; cylinder 200; negative/zero burst; duplicate PID; wrong CSV header; missing file; allocation > max; unknown process; bad strategy; bad Bash arguments |
| Invariants | waiting = turnaround − burst; Optimal ≤ LRU; LOOK ≤ SCAN; SRTF lowest waiting |

Errors raise `ValidationError`; the menu reports them and continues (`outputs/menu_session_trace.txt`). Activity
(starts, runs, warnings, Bash calls, exceptions) is written to `logs/activity.log`.

## Phase 5 – Demonstration and documentation
Run `./run.sh all`, then open `outputs/`. Screenshots: `screenshot_1_scheduler.png` … `screenshot_4_menu_validation.png`.
Demo script: (1) option 6 – whole system; (2) option 1 with quantum 2 vs 8; (3) option 2 with invalid input to show
error handling; (4) option 5 to show Bash integration; (5) `./run.sh test`.

**Limitations / future work.** Single-CPU, discrete-time simulation; no I/O bursts or multilevel queues; Banker's
handles one request at a time; could add a GUI or multi-level feedback queue.

**Originality.** All algorithms, validators, reporting and Bash tooling were implemented from scratch for this project;
no third-party code beyond the Python standard library and matplotlib.
