WINDOWS QUICK START
===================

1. Install Python 3 for Windows from https://www.python.org/downloads/windows/
   During installation, tick "Add Python to PATH".
2. Extract this ZIP file fully (do not run the program from inside the ZIP).
3. Open the extracted os_sim folder.
4. Double-click SETUP_WINDOWS.bat and wait for Matplotlib to install.
5. Double-click RUN_WINDOWS.bat to open the project menu.

Other commands:
- RUN_WINDOWS.bat demo   : run all sample demonstrations
- RUN_WINDOWS.bat test   : run automated tests

Windows note:
The Python simulations work on Windows. The live Bash-based process collector is
Unix-specific and is skipped by the Windows system report. To run the Bash helper
scripts as well, install Git for Windows (Git Bash) or use WSL.

If Windows blocks the .bat file, right-click it and choose Open. Keep all project
folders together; the Python modules and data folder must remain beside main.py.
